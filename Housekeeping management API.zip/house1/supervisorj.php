<?php
session_start();
require_once('dbh.php');

// Check if the session variable is set
if (isset($_SESSION["firstName"])) {
    $supervisorName = $_SESSION["firstName"];

    // SQL query to select jobs assigned to the logged-in supervisor that are not completed
    $sql = "SELECT job_id, floor_no FROM job WHERE supervisor = '$supervisorName' AND status != 'completed'";

    $result = mysqli_query($conn, $sql);
    if (!$result) {
        die(json_encode(array("error" => mysqli_error($conn))));
    }

    // Check if a job has been marked as "completed" and delete it from the database
    if (isset($_GET['completed_job_id'])) {
        $completedJobId = $_GET['completed_job_id'];
        $deleteSql = "DELETE FROM job WHERE job_id = '$completedJobId'";
        $deleteResult = mysqli_query($conn, $deleteSql);

        if ($deleteResult) {
            // Job successfully deleted
            echo json_encode(array("message" => "Job marked as completed and deleted."));
        } else {
            // Error occurred while deleting the job
            echo json_encode(array("error" => "Error deleting the job."));
        }
    }
} else {
    // If the session variable is not set correctly
    echo json_encode(array("error" => "Session variable not set correctly."));
}
?>
