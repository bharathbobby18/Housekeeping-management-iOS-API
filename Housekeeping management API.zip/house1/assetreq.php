<?php
require_once('dbh.php'); // Ensure that dbh.php contains your database connection logic

// Initialize a response array
$response = array();

// SQL query to select assets
$sql = "SELECT asset_id, asset_name, asset_quantity FROM assets";
$result = mysqli_query($conn, $sql);
if (!$result) {
    $response['error'] = "Database error: " . mysqli_error($conn);
} else {
    $assets = array();
    while ($asset = mysqli_fetch_assoc($result)) {
        $assets[] = $asset;
    }
    $response['assets'] = $assets;
}

// Handle asset request submission
if (isset($_POST['submit_request'])) {
    $assetID = $_POST['asset_id'];
    $quantity = $_POST['quantity'];
    $bioID = $_SESSION['bio_id'];

    // Perform input validation and sanitation here

    // Check if the asset quantity is greater than 0 before allowing the request
    $checkQuantitySql = "SELECT asset_quantity FROM assets WHERE asset_id = '$assetID'";
    $quantityResult = mysqli_query($conn, $checkQuantitySql);

    if (!$quantityResult) {
        $response['error'] = "Database error: " . mysqli_error($conn);
    } else {
        $assetQuantity = mysqli_fetch_assoc($quantityResult)['asset_quantity'];

        if ($assetQuantity > 0) {
            // Use prepared statements to prevent SQL injection
            $insertSql = "INSERT INTO requestasset (asset_id, request_quantity, bio_id) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insertSql);
            mysqli_stmt_bind_param($stmt, "iii", $assetID, $quantity, $bioID);
            $insertResult = mysqli_stmt_execute($stmt);

            if ($insertResult) {
                $response['success'] = "Asset request submitted successfully.";
            } else {
                $response['error'] = "Database error: " . mysqli_error($conn);
            }
        } else {
            $response['error'] = "Sorry, there is no asset available for this request.";
        }
    }
}

// Handle asset addition form submission
if (isset($_POST['submit_add_asset'])) {
    $newAssetID = $_POST['new_asset_id'];
    $newAssetQuantity = $_POST['new_asset_quantity'];

    // Perform input validation and sanitation here

    // Use prepared statements to prevent SQL injection
    $insertAssetSql = "INSERT INTO assets (asset_id, asset_quantity) VALUES (?, ?)";
    $stmt = mysqli_prepare($conn, $insertAssetSql);
    mysqli_stmt_bind_param($stmt, "ii", $newAssetID, $newAssetQuantity);
    $insertAssetResult = mysqli_stmt_execute($stmt);

    if ($insertAssetResult) {
        $response['success'] = "Asset added successfully.";
    } else {
        $response['error'] = "Database error: " . mysqli_error($conn);
    }
}

// Return the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);
?>
