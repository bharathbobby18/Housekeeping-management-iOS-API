<?php
session_start();

$jobId = isset($_GET['job_id']) ? $_GET['job_id'] : null;
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housekeeping";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['selected_workers']) && isset($_POST['classroom'])) {
        $selectedWorkers = $_POST['selected_workers'];
        $classroom = $_POST['classroom'];
        $maxWorkers = 3; // Adjust this value as needed

        if (count($selectedWorkers) > $maxWorkers) {
            die("You can only choose up to $maxWorkers workers for a single classroom.");
        }

        // Get worker names
        $workerNames = array();
        foreach ($selectedWorkers as $bioId) {
            $sql = "SELECT `firstName` FROM `userinfo` WHERE `bio_id` = '$bioId'";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $workerNames[] = $row['firstName'];
            } else {
                die("Query error: " . mysqli_error($conn));
            }
        }

        $workerNamesStr = implode(", ", $workerNames);

        // Use prepared statement to avoid SQL injection
        $updateSql = "UPDATE `job` SET `assigned_classroom` = ? WHERE `job_id` = ?";
        $updateStatement = $conn->prepare($updateSql);
        $updateStatement->bind_param("ss", $workerNamesStr, $jobId);

        // Execute the update statement
        $updateResult = $updateStatement->execute();

        // Check for errors
        if (!$updateResult) {
            die("Update error: " . $updateStatement->error);
        } else {
            echo "Update successful!";
        }

        // Close the statement
        $updateStatement->close();

     // For debugging, print the worker names and job ID
echo "Worker Names: " . $workerNamesStr . "<br>";
// For debugging, print the job_id
echo "Job ID: " . htmlspecialchars($jobId) . "<br>";



        // Display a success message and redirect
       // Display a success message and redirect
echo '<script>
alert("Your job has been scheduled.");
setTimeout(function(){
    window.location.href = "sloginwel.php?job_id=' . htmlspecialchars($jobId) . '";
}, 2000);
</script>';
    }
}
?>
