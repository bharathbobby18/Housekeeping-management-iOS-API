<?php //error_reporting(0); ?> 
 <?php

include 'dbh.php';
$bioid =$_GET['email'];
$password =$_GET['pass'];
$type=$_GET['type'];
//$bioid = 'test@gmail.com'; 
//$_POST['bioid'];
//$password ='pass123';
//echo  $bioid. $password;   //$_POST['password'];
$loginqry = "SELECT * FROM userinfo WHERE bio_id = '$bioid' AND password = '$password' AND Designation = '$type'";
//$loginqry = "SELECT * FROM users WHERE bioid = 10101 AND password ='pass123'";
$qry = mysqli_query($conn, $loginqry);
if(mysqli_num_rows($qry) > 0){
$userObj = mysqli_fetch_assoc($qry);
$response['status'] = true;
$response['message']= " Login Successfully";
$response['data'] = $userObj;
}
else{
$response['status'] = false;
$response['message']= "Login Failed";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?> 