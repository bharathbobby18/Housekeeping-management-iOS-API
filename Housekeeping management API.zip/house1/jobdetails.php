<?php
session_start();
require_once('dbh.php'); // Include your database connection code here

$response = array();

// Check if the job_id parameter is set in the URL
if (isset($_GET['job_id'])) {
    $job_id = $_GET['job_id'];

    // SQL query to retrieve job details based on job_id
    $sql = "SELECT * FROM job WHERE job_id = '$job_id'";
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        $response['status'] = false;
        $response['message'] = "Error: " . mysqli_error($conn);
    } else {
        $job = mysqli_fetch_assoc($result);
        $response['status'] = true;
        $response['job'] = $job;
    }
} else {
    $response['status'] = false;
    $response['message'] = "Job ID not provided.";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
