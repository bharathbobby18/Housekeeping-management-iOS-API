<?php

session_start();
require_once('dbh.php');
$response = array();

$supervisorName = isset($_SESSION["bio_id"]) ? $_SESSION["bio_id"] : ''; // Default value is an empty string

// SQL query to select all jobs assigned to the logged-in supervisor, joining with the userinfo table
$sql = "SELECT job.job_id, job.floor_no, job.from_date, job.to_date, job.status, userinfo.firstName as supervisor 
        FROM job 
        INNER JOIN userinfo 
        ON job.supervisor = userinfo.bio_id 
        WHERE job.supervisor = '$supervisorName'";

// Modify the SQL query to include the bio_id condition
if (isset($_GET['bio_id'])) {
    $bioId = $_GET['bio_id'];
    $sql = "SELECT job.job_id, job.floor_no, job.from_date, job.to_date, job.status, userinfo.firstName as supervisor 
            FROM job 
            INNER JOIN userinfo 
            ON job.supervisor = userinfo.bio_id 
            WHERE job.supervisor = '$bioId'";
}

$result = mysqli_query($conn, $sql);

if (!$result) {
    $response['status'] = false;
    $response['message'] = "Error: " . mysqli_error($conn);
} else {
    $jobs = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $status = $row['status'] ? 'Completed' : 'Pending'; // Check if the status is empty or not
        $job = array(
            'job_id' => $row['job_id'],
            'floor_no' => $row['floor_no'],
            'from_date' => $row['from_date'],
            'to_date' => $row['to_date'],
            'status' => $status,
            'supervisor' => $row['supervisor'],
        );
        $jobs[] = $job;
    }

    $response['status'] = true;
    $response['jobs'] = $jobs;
}

// Check if a job has been marked as "completed" and delete it from the database
if (isset($_GET['completed_job_id'])) {
    $completedJobId = $_GET['completed_job_id'];
    $deleteSql = "DELETE FROM job WHERE job_id = '$completedJobId'";
    $deleteResult = mysqli_query($conn, $deleteSql);

    if ($deleteResult) {
        // Job successfully deleted
        $response['status'] = true;
        $response['message'] = "Job marked as completed and deleted.";
    } else {
        // Error occurred while deleting the job
        $response['status'] = false;
        $response['message'] = "Error deleting the job: " . mysqli_error($conn);
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>
