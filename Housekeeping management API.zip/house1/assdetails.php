<?php
header('Content-Type: application/json'); // Set the header to indicate JSON content

// Initialize the response array
$response = array();

// Check if a bio_id parameter is provided in the URL
if (isset($_GET['bio_id'])) {
    $bio_id = $_GET['bio_id'];
    require_once('dbh.php'); // Include your database connection code here

    // Query to fetch asset details and asset name based on bio_id
    $detailsSql = "SELECT ra.asset_id, ra.request_quantity, a.asset_name
                   FROM requestasset ra
                   JOIN assets a ON ra.asset_id = a.asset_id
                   WHERE ra.bio_id = '$bio_id'";

    $detailsResult = mysqli_query($conn, $detailsSql);

    if ($detailsResult && mysqli_num_rows($detailsResult) > 0) {
        // Your existing HTML and form generation code

        // Create the response data
        $response['status'] = 'success';
        $response['message'] = 'Asset details retrieved successfully';
        $response['data'] = array();

        while ($row = mysqli_fetch_assoc($detailsResult)) {
            $assetData = array(
                'asset_id' => $row['asset_id'],
                'asset_name' => $row['asset_name'],
                'request_quantity' => $row['request_quantity']
            );
            // Add the asset data to the response
            $response['data'][] = $assetData;
        }

        // Check if the "Request Accept" button was pressed
        if (isset($_POST['request_accept'])) {
            // Your existing code for updating and inserting operations

            // Add a success message to the response
            $response['message'] = 'Asset quantities updated and details deleted successfully.';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'No asset details found for this Bio ID.';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Please provide a valid Bio ID.';
}

// Encode the response array to JSON and echo it
echo json_encode($response);
?>
