<?php
session_start();

$jobId = isset($_GET['job_id']) ? $_GET['job_id'] : null;
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housekeeping";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function determineAssignedColumn($classroom) {
    if ($classroom === null) {
        // Handle the case where $classroom is null
        die("Invalid classroom value");
    }

    // Extract numeric part from the classroom
    $numericClassroom = filter_var($classroom, FILTER_SANITIZE_NUMBER_INT);

    // Define your rules for assigning columns based on classroom ranges
    if ($numericClassroom >= 1 && $numericClassroom <= 30) {
        if ($numericClassroom >= 1 && $numericClassroom <= 5) {
            return "assigned_classroom";
        } elseif ($numericClassroom >= 6 && $numericClassroom <= 10) {
            return "assigned_classroom2";
        } elseif ($numericClassroom >= 11 && $numericClassroom <= 15) {
            return "assigned_classroom3";
        } elseif ($numericClassroom >= 16 && $numericClassroom <= 20) {
            return "assigned_classroom4";
        } elseif ($numericClassroom >= 21 && $numericClassroom <= 25) {
            return "assigned_classroom5";
        } elseif ($numericClassroom >= 26 && $numericClassroom <= 30) {
            return "assigned_classroom6";
        }
    } elseif (in_array($classroom, ['restroom', 'staffroom', 'lab'])) {
        switch ($classroom) {
            case 'restroom':
                return "assigned_classroom7";
            case 'staffroom':
                return "assigned_classroom8";
            case 'lab':
                return "assigned_classroom9";
        }
    }

    // Default case, you can adjust this as needed
    die("Invalid classroom value");
}

// Rest of your code...

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['selected_workers']) && isset($_POST['classroom'])) {
        $selectedWorkers = $_POST['selected_workers'];
        $classroom = $_POST['classroom'];
        $maxWorkers = 3; // Adjust this value as needed
        if (count($selectedWorkers) > $maxWorkers) {
            die("You can only choose up to $maxWorkers workers for a single classroom.");
        }

        foreach ($selectedWorkers as $bioId) {
            // Check if the worker is busy
            $checkBusySql = "SELECT busy FROM userinfo WHERE bio_id = '$bioId'";
            $checkBusyResult = mysqli_query($conn, $checkBusySql);

            if ($checkBusyResult) {
                $busyRow = mysqli_fetch_assoc($checkBusyResult);
                $busyStatus = $busyRow['busy'];

                // If the worker is busy, prevent the selection
                if ($busyStatus == 1) {
                    die("Worker with Bio ID $bioId is currently busy and cannot be selected.");
                }
            } else {
                die("Query error: " . mysqli_error($conn));
            }
        }

        // Update the busy status for selected workers
        foreach ($selectedWorkers as $bioId) {
            $updateBusySql = "UPDATE userinfo SET busy = 1 WHERE bio_id = '$bioId'";
            $updateBusyResult = mysqli_query($conn, $updateBusySql);

            if (!$updateBusyResult) {
                die("Update busy status error: " . mysqli_error($conn));
            }
        }

        $assignedColumn = determineAssignedColumn($classroom);

        $workerNames = array();

        foreach ($selectedWorkers as $bioId) {
            $sql = "SELECT firstName FROM userinfo WHERE bio_id = '$bioId'";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $workerNames[] = $row['firstName'];
            } else {
                die("Query error: " . mysqli_error($conn));
            }
        }

        $workerNamesStr = implode(", ", $workerNames);
        $updateSql = "UPDATE job SET $assignedColumn = '$workerNamesStr' WHERE job_id = '$jobId'";
        
        // Debug: Echo the SQL query for verification
        echo "Update SQL: $updateSql";

        $updateResult = mysqli_query($conn, $updateSql);

        if (!$updateResult) {
            die("Update error: " . mysqli_error($conn));
        }

        // Get the floor_no for redirection
        $floorNoSql = "SELECT floor_no FROM job WHERE job_id = '$jobId'";
        $floorNoResult = mysqli_query($conn, $floorNoSql);
        $floorNoRow = mysqli_fetch_assoc($floorNoResult);
        $floorNo = $floorNoRow['floor_no'];

        // Display a success message and redirect to room_list.php with the same job ID and floor_no
        echo '<script>alert("Your job has been scheduled.");</script>';
        echo '<script>
                setTimeout(function(){
                    window.location.href = "sloginwel.php?job_id=' . $jobId . '&floor_no=' . $floorNo . '";
                }, 2000);
              </script>';
    }
}

$sql = "SELECT firstName, bio_id FROM userinfo WHERE designation = 'worker'";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query error: " . mysqli_error($conn));
}
?>