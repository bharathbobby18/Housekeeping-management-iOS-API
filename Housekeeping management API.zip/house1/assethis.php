<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housekeeping";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array();

// Get the bio_id from the URL parameter
if (isset($_GET['bio_id'])) {
    $bio_id = $_GET['bio_id'];

    // Query the asset_history table for history records associated with the bio_id
    $sql = "SELECT asset_id, asset_name, asset_quantity, date FROM asset_history WHERE bio_id = $bio_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            $response['data'][] = $row; // Storing data under 'data' key
        }
        echo json_encode($response);
    } else {
        echo json_encode(array('message' => 'No records found.'));
    }
} else {
    echo json_encode(array('message' => 'Invalid bio_id.'));
}

$conn->close();
?>
