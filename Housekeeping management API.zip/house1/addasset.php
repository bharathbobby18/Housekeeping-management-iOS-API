<?php

include 'dbh.php'; // Include your database connection file here

$asset_id = $_GET["asset_id"];
$asset_name = $_GET["assetName"];
$asset_quantity = $_GET["assetQuantity"];

$sql = "INSERT INTO assets (asset_id, asset_name, asset_quantity) VALUES ('$asset_id', '$asset_name', '$asset_quantity')";
$res = mysqli_query($conn, $sql);

$supervisor = ''; // initializing the supervisor variable

if ($res) {
    $response['status'] = true;
    $response['message'] = "Data inserted successfully!";
} else {
    $response['status'] = false;
    $response['message'] = "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$supervisor = json_encode($response); // storing JSON response in the supervisor variable

header('Content-Type: application/json; charset=UTF-8');
echo $supervisor;

// Close the database connection if necessary
// mysqli_close($conn);

?>
