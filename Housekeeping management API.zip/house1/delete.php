<?php
require_once('dbh.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['bio_id'])) {
        $bio_id = $_POST['bio_id'];
        $sql = "DELETE FROM userinfo WHERE bio_id = $bio_id";
        $result = mysqli_query($conn, $sql);

        if (!$result) {
            $response = array('status' => false, 'message' => mysqli_error($conn));
            echo json_encode($response);
        } else {
            $response = array('status' => true, 'message' => 'Record deleted successfully');
            echo json_encode($response);
        }
    }
}
?>
