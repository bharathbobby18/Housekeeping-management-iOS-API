<?php
session_start();
require_once('dbh.php'); // Include your database connection code here

// Check if a bio_id parameter is provided in the URL
if (isset($_GET['bio_id'])) {
    $bio_id = mysqli_real_escape_string($conn, $_GET['bio_id']);

    // Query to fetch asset details and asset name based on bio_id
    $detailsSql = "SELECT ra.asset_id, ra.request_quantity, a.asset_name
                   FROM requestasset ra
                   JOIN assets a ON ra.asset_id = a.asset_id
                   WHERE ra.bio_id = '$bio_id'";
    
    $detailsResult = mysqli_query($conn, $detailsSql);

    if ($detailsResult && mysqli_num_rows($detailsResult) > 0) {
        // Initialize a flag to track if any errors occur during the update and insert operations
        $errorOccurred = false;
        $response = array();

        // Retrieve the firstName associated with the bio_id from the userinfo table
        $userInfoSql = "SELECT firstName FROM userinfo WHERE bio_id = '$bio_id'";
        $userInfoResult = mysqli_query($conn, $userInfoSql);

        if ($userInfoResult && mysqli_num_rows($userInfoResult) > 0) {
            $userInfoRow = mysqli_fetch_assoc($userInfoResult);
            $firstName = $userInfoRow['firstName'];

            // Define $assetQuantitiesToUpdate or replace it with the appropriate array
            $assetQuantitiesToUpdate = array(/* Your asset IDs and quantities here */);

            // Update asset_quantity in the assets table and add to asset_history
            foreach ($assetQuantitiesToUpdate as $assetID => $quantity) {
                // Update asset_quantity in the assets table
                $updateSql = "UPDATE assets SET asset_quantity = asset_quantity - $quantity WHERE asset_id = '$assetID'";
                $updateResult = mysqli_query($conn, $updateSql);

                if (!$updateResult) {
                    $errorOccurred = true;
                    $response['error'][] = "Error updating asset quantity for asset ID: $assetID - " . mysqli_error($conn);
                } else {
                    // Get the current date and time with year, month, day, hour, minute, and second
                    $currentDate = date("Y-m-d H:i:s");

                    // Fetch asset details
                    $detailsRow = mysqli_fetch_assoc($detailsResult);
                    $assetName = $detailsRow['asset_name'];

                    // After updating the asset quantity, insert a record into the asset_history table with asset_id, bio_id, firstName, asset_name, asset_quantity, and date
                    $historySql = "INSERT INTO asset_history (asset_id, bio_id, firstName, asset_name, asset_quantity, date) 
                                   VALUES ('$assetID', '$bio_id', '$firstName', '$assetName', $quantity, '$currentDate')";
                    $historyResult = mysqli_query($conn, $historySql);

                    if (!$historyResult) {
                        $errorOccurred = true;
                        $response['error'][] = "Error recording asset history for asset ID: $assetID - " . mysqli_error($conn);
                    }
                }
            }

            if (!$errorOccurred) {
                // Delete the requested asset details
                $deleteSql = "DELETE FROM requestasset WHERE bio_id = '$bio_id'";
                $deleteResult = mysqli_query($conn, $deleteSql);

                if ($deleteResult) {
                    $response['success'] = "Asset quantities updated and details deleted successfully.";
                } else {
                    $response['error'][] = "Error deleting asset details: " . mysqli_error($conn);
                }
            } else {
                $response['error'][] = "Errors occurred during the update and history recording.";
            }
        } else {
            $response['error'][] = "No user information found for this Bio ID.";
        }

        // Send JSON response
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        echo "No asset details found for this Bio ID.";
    }
} else {
    // Handle the case when no bio_id parameter is provided
    echo "Please provide a valid Bio ID.";
}
?>
