<?php

include 'dbh.php'; // Include your database connection file here

// Assuming the form data is received via POST
$classroom_name = $_POST['classroom_name'];
$job_id = $_POST['job_id'];
$worker_names_string = $_POST['worker_names']; // Assuming worker names are provided as a string separated by a delimiter

$worker_names = explode(',', $worker_names_string); // Convert the string to an array using the explode function

$response = array();

// You can loop through the array of worker names and insert them into the database
foreach ($worker_names as $worker_name) {
    $insertWorkerSql = "INSERT INTO classroom_details (classroom_name, job_id, worker_name) 
                        VALUES ('$classroom_name', '$job_id', '$worker_name')";

    if (mysqli_query($conn, $insertWorkerSql)) {
        $response['status'] = true;
        $response['message'] = "Classroom details and worker names have been added successfully.";
    } else {
        $response['status'] = false;
        $response['message'] = "Error: " . mysqli_error($conn);
        break; // Break the loop if an error occurs during insertion
    }
}

mysqli_close($conn);

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
