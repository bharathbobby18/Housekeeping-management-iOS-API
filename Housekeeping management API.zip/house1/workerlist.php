<?php
session_start();
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$dbname = "housekeeping";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query the database to get worker names and bio IDs for all workers
$sql = "SELECT `firstName`, `bio_id`
        FROM `userinfo`
        WHERE `designation` = 'worker'";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Query error: " . mysqli_error($conn)); // Display the error message
}

// Create an array to store the worker data
$workers = array();

while ($row = mysqli_fetch_assoc($result)) {
    $worker = array(
        'bio_id' => $row['bio_id'],
        'firstName' => $row['firstName']
    );

    $workers[] = $worker;
}

// Close the database connection
mysqli_close($conn);

// Create a JSON response
$response = array(
    'data' => $workers
);

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>