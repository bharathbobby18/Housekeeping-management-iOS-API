<?php
// Database connection parameters
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'housekeeping';

// Create a database connection
$mysqli = new mysqli($host, $username, $password, $database);

// Check the connection
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Prepare and execute the SQL query
$query = "SELECT firstName, bio_id FROM userinfo WHERE designation = 'manager'";
$result = $mysqli->query($query);

if (!$result) {
    die('Query failed: ' . $mysqli->error);
}

// Fetch the results into an associative array
$supervisor = array();
while ($row = $result->fetch_assoc()) {
    $supervisor[] = $row;
}

// Close the database connection
$mysqli->close();

// Create an associative array with the key "data"
$response = array("data" => $supervisor);

// Return the results as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
