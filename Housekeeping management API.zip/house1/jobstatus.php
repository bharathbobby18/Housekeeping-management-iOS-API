<?php

$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "housekeeping";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if (!$conn) {
    echo "Database Connection Failed";
    exit();
}

$response = array();

// Query to fetch data from the 'job' table with a CASE statement
$sql = "SELECT job_id, from_date, to_date, floor_no, supervisor, 
    CASE 
        WHEN status = 'Completed' THEN 'Completed'
        ELSE 'Pending'
    END AS status,
    image -- Include the 'image' column in the query
    FROM job";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $job = array(
            'job_id' => $row["job_id"],
            'from_date' => $row["from_date"],
            'to_date' => $row["to_date"],
            'floor_no' => $row["floor_no"],
            'supervisor' => $row["supervisor"],
            'status' => $row["status"],
            'image' => $row["image"]
        );

        array_push($response, $job);
    }
} else {
    $response['status'] = false;
    $response['message'] = "No job records found.";
}

$conn->close();

// Adding the response array under a key called 'data'
$responseData['data'] = $response;

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($responseData, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
?>
