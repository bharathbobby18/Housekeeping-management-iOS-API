<?php
header('Content-Type: application/json');
session_start();
require_once('dbh.php');

// SQL query to select distinct bio_id values from the requestasset table where bio_id is not NULL
$sql = "SELECT DISTINCT bio_id FROM requestasset WHERE bio_id IS NOT NULL";
$result = mysqli_query($conn, $sql);
if (!$result) {
    die(json_encode(["error" => mysqli_error($conn)]));
}

$response = array();
$data = array();

while ($row = mysqli_fetch_assoc($result)) {
    $bioID = $row['bio_id'];
    // Query to fetch first name from userinfo table
    $firstNameQuery = "SELECT firstname FROM userinfo WHERE bio_id = '$bioID'";
    $firstNameResult = mysqli_query($conn, $firstNameQuery);
    $firstName = "";
    if ($firstNameRow = mysqli_fetch_assoc($firstNameResult)) {
        $firstName = $firstNameRow['firstname'];
    }

    $data[] = array(
        "bio_id" => $bioID,
        "firstname" => $firstName
    );
}

$response['data'] = $data;

echo json_encode($response);
?>
