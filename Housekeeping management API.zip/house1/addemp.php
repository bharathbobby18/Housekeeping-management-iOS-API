<?php

include 'dbh.php';
$response = array();

if(isset($_POST["firstName"]) && isset($_POST["lastName"]) && isset($_POST["email"]) && isset($_POST["birthday"]) && isset($_POST["contact"]) && isset($_POST["bio_id"]) && isset($_POST["password"]) && isset($_POST["Designation"]) && isset($_POST["qualification"])){

    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $email = $_POST["email"];
    $birthday = $_POST["birthday"];
    $contact = $_POST["contact"];
    $bio_id = $_POST["bio_id"];
    $password = $_POST["password"];
    $Designation = $_POST["Designation"];
    $qualification = $_POST["qualification"];

    $loginqry = "INSERT INTO userinfo (firstName, lastName, email, birthday, contact, bio_id, password, Designation, qualification) VALUES ('$firstName', '$lastName', '$email', '$birthday', '$contact', '$bio_id', '$password', '$Designation', '$qualification')";

    $res = mysqli_query($conn, $loginqry);

    if($res){
        $response['status'] = true;
        $response['message']= "Login Successfully";
    } else {
        $response['status'] = false;
        $response['message']= "Login Failed";
    }
} else {
    $response['status'] = false;
    $response['message'] = "Some parameters are missing";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>
