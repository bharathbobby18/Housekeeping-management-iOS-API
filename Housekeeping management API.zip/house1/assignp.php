<?php

include 'dbh.php'; // Include your database connection file here

$from = $_POST['from'];
$to = $_POST['to'];
$floor_no = $_POST['floor_no'];
$supervisor = $_POST['supervisor'];

$insertJobSql = "INSERT INTO job (from_date, to_date, floor_no, supervisor) 
                 VALUES ('$from', '$to', '$floor_no', '$supervisor')";

$response = array();

if (mysqli_query($conn, $insertJobSql)) {
    $job_id = mysqli_insert_id($conn);
    $response['status'] = true;
    $response['message'] = "The job has been assigned successfully.";
} else {
    $response['status'] = false;
    $response['message'] = "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
