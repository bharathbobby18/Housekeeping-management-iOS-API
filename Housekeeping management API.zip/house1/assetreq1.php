<?php

// Include your database connection file here
include 'dbh.php';

$response = array(); // Initialize the response array

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you are sending the data as JSON
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    // Check if 'bio_id' is provided
    if (!isset($data['bio_id'])) {
        $response['status'] = false;
        $response['message'] = "Error: 'bio_id' not provided in the request.";
    } else {
        $bio_id = $data['bio_id'];

        // Check if 'assetReqListDetails' is provided
        if (!isset($data['assetReqListDetails'])) {
            $response['status'] = false;
            $response['message'] = "Error: 'assetReqListDetails' not provided in the request.";
        } else {
            $assetReqListDetails = $data['assetReqListDetails'];

            foreach ($assetReqListDetails as $asset) {
                // Check if the required keys are present in each asset entry
                if (!isset($asset['asset_id'], $asset['request_quantity'])) {
                    $response['status'] = false;
                    $response['message'] = "Error: Each 'assetReqListDetails' entry must have 'asset_id' and 'request_quantity'.";
                    break;
                }

                $asset_id = $asset['asset_id'];
                $request_quantity = $asset['request_quantity'];

                // Perform your database insertion here, including bio_id
                $sql = "INSERT INTO requestasset (asset_id, request_quantity, bio_id) VALUES ('$asset_id', '$request_quantity', '$bio_id')";
                $res = mysqli_query($conn, $sql);

                if ($res) {
                    $response['status'] = true;
                    $response['message'] = "Data inserted successfully.";
                    $response['assetReqListDetails'][] = array('asset_id' => $asset_id, 'request_quantity' => $request_quantity);
                } else {
                    $response['status'] = false;
                    $response['message'] = "Error: " . mysqli_error($conn);
                    break;
                }
            }
        }
    }
} else {
    $response['status'] = false;
    $response['message'] = "Error: Invalid request method. Use POST.";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

// Close the database connection if necessary
// mysqli_close($conn);

?>
