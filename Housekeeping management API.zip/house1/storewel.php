<?php
require_once('dbh.php');

$response = array(); // Initialize a response array

$sql = "SELECT asset_id, asset_name, asset_quantity FROM assets";
$result = mysqli_query($conn, $sql);

if (!$result) {
    $response['error'] = "Database error: " . mysqli_error($conn);
} else {
    $assets = array();
    while ($userinfo = mysqli_fetch_assoc($result)) {
        $assets[] = $userinfo;
    }
    $response['assets'] = $assets;
}

// Return the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);
?>
