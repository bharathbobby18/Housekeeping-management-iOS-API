//
//  TabbarVC.swift
//  HouseKeeping
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class TabbarVC: UITabBarController {
    
    var designation = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SelectProfile()
    }
    
    func SelectProfile(){
        
        if designation == "Admin" {
            
            DispatchQueue.main.async {
                let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                viewController.name1 = "Manage Employee"
                viewController.name2 = "Manage Rooms"
//                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
        else if designation == "manager" {
            DispatchQueue.main.async {
                let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                viewController.name1 = "Assign Works"
                viewController.name2 = "Ratings"
//                self.navigationController?.pushViewController(viewController, animated: true)
            }
            
            
        }
        else if designation == "supervisor" {
            DispatchQueue.main.async {
                let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                viewController.name1 = "Job"
                viewController.name2 = "Request Assests"
//                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
        else if designation == "storekeeper" {
            DispatchQueue.main.async {
                let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                viewController.name1 = "Requested Assests "
                viewController.name2 = "Assest History"
//                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
    }
    
    
}
