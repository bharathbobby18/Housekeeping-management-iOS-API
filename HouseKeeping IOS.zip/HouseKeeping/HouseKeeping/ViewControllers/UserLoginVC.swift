//
//  UserLoginVC.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class UserLoginVC: UIViewController {
    
    @IBOutlet weak var admin: UIView!
    @IBOutlet weak var manager: UIView!
    @IBOutlet weak var superVisor: UIView!
    @IBOutlet weak var storeKeeper: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        self.admin.addAction(for: .tap, Action: {
            UserDefaultsManager.shared.setValue("admin", forKey: "Profile")
            if let userName: String? = UserDefaultsManager.shared.getValue(forKey: "Profile") {
                print("User Name: \(userName ?? "N/A")")
            }
           let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(viewController, animated: true)
        })
        
        self.manager.addAction(for: .tap, Action: {
            UserDefaultsManager.shared.setValue("manager", forKey: "Profile")

           let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(viewController, animated: true)
        })
        
        
        self.superVisor.addAction(for: .tap, Action: {
            UserDefaultsManager.shared.setValue("supervisor", forKey: "Profile")

           let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(viewController, animated: true)
        })
        
        self.storeKeeper.addAction(for: .tap, Action: {
            UserDefaultsManager.shared.setValue("storekeeper", forKey: "Profile")
           let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(viewController, animated: true)
        })
    }
    

}
