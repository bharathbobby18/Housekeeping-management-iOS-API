//
//  RequestedAssests.swift
//  HouseKeeping
//
//  Created by SAIL on 24/10/23.
//

import UIKit

class RequestedAssests: UIViewController {

    @IBOutlet weak var requestTable: UITableView! {
        didSet {
            requestTable.delegate = self
            requestTable.dataSource = self
        }
    }
    var requestedData : RequestedAssetModel? {
        didSet {
            if let requestedData = requestedData {
                print(requestedData)
            }
            else {
                print("NO Data Available")
            }
        }
    }
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        self.GetRequestedAPI()

    }
    
    func GetRequestedAPI() {
        APIHandler().getAPIValues(type: RequestedAssetModel.self, apiUrl: ServiceAPI.requestedAssets, method: "GET") { Result in
            switch Result {
            case.success(let data):
                print(data)
                self.requestedData = data
                DispatchQueue.main.async {
                    self.requestTable.reloadData()
                }
            case.failure(let error):
                print(error)
                
            }
        }
    }
    


}


extension RequestedAssests: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return requestedData?.data?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = requestTable.dequeueReusableCell(withIdentifier: "RequestTabCell") as! RequestTabCell
        cell.name_Lbl.text =  requestedData?.data?[indexPath.row].firstname ?? ""
        cell.bioId_Lbl.text = requestedData?.data?[indexPath.row].bioID ?? ""
       return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "AssetReequestVC") as! AssetReequestVC
        nextVC.bioID = requestedData?.data?[indexPath.row].bioID ?? ""
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
}


class  RequestTabCell: UITableViewCell {
    
    @IBOutlet weak var bioId_Lbl: UILabel!
    
    @IBOutlet weak var name_Lbl: UILabel!
}
