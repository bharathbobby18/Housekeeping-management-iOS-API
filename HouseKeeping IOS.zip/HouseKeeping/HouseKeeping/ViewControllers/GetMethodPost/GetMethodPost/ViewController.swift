//
//  ViewController.swift
//  GetMethodPost
//
//  Created by SAIL on 13/10/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        postDataToAPI()
        // Do any additional setup after loading the view.
    }
    func postDataToAPI() {
        // Define the URL of the API
        let apiUrl = "http://172.17.57.227//house1/addbul.php"
        
        // Create a URLRequest with the API URL
        var request = URLRequest(url: URL(string: apiUrl)!)
        
        // Set the HTTP method to POST
        request.httpMethod = "POST"
        
        // Define the parameters to send as FormData
        let parameters: [String: String] = [
            "building_id": "55",
            "buildingname": "sail",
            "floor_no": "2",
            "room_no": "22",
            "room_type": "lab"
        ]
        
        // Create a FormData string from the parameters
        let formData = parameters.map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)" }.joined(separator: "&")

        // Set the HTTP body with the FormData
        request.httpBody = formData.data(using: .utf8)
        
        // Create a URLSession and data task to perform the POST request
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            // Handle the response and error here
            print(data)
            print(response)
            print(error)

        }
        
        task.resume()
    }


}

