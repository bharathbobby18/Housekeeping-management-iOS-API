//
//  JobAssignedVC.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class JobAssignedVC: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var week1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        week1.addAction(for: .tap) {
            let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "FloorAssignedVC") as! FloorAssignedVC
             self.navigationController?.pushViewController(viewController, animated: true)
        }
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }

}
