//
//  HomeViewController.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var firstName: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var jobView: UILabel!
    @IBOutlet weak var reqAssestView: UIView!
    @IBOutlet weak var topView: UIView!
    
    var name2 = String()
    var name1 = String()
    var designation = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if let firstNameStr : String? = UserDefaultsManager.shared.getValue(forKey: "FirstName") {
            firstName.text = firstNameStr
        }
        if let profile : String? = UserDefaultsManager.shared.getValue(forKey: "Profile") {
            self.designation = profile ?? ""
            SelectProfile()

        }
        
        jobView.addAction(for: .tap) {
            self.SelectedJob()
        }
        lbl2.addAction(for: .tap) {
            self.AssignJob()
            
        }
        
        topView.layer.cornerRadius = 40
//        topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]

    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
//        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    func SelectProfile(){
        
        if designation == "admin" {
            jobView.text = "Manage Employee"
            lbl2.text = "Manage Rooms"
        }
        else if designation == "manager" {
            jobView.text = "Assign Work"
            lbl2.text = "Job Status"
        }
        else if designation == "supervisor" {
            jobView.text = "Job"
            lbl2.text = "Request Assests"
        }
        else if designation == "storekeeper" {
            jobView.text = "Requested Assests"
            lbl2.text = "Assest History"

        }
    }
    

    func SelectedJob(){
        if UserDefaultsManager.shared.getValue(forKey: "Profile") == "admin" {
            let manageEmpVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "ManageEmployee") as! ManageEmployee
            self.navigationController?.pushViewController(manageEmpVC, animated: true)
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "manager" {
            let manageEmpVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "AssignJobVC") as! AssignJobVC
            self.navigationController?.pushViewController(manageEmpVC, animated: true)
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "supervisor"{
            let manageEmpVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SupervisorJobVC") as! SupervisorJobVC
            self.navigationController?.pushViewController(manageEmpVC, animated: true)
            
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "storekeeper"{
            
            let manageEmpVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "RequestedAssests") as! RequestedAssests
            self.navigationController?.pushViewController(manageEmpVC, animated: true)
        }
        
    }
    func AssignJob(){
        if UserDefaultsManager.shared.getValue(forKey: "Profile") == "admin" {
            let manageEmpVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "FillDetailsRooms") as! FillDetailsRooms
            self.navigationController?.pushViewController(manageEmpVC, animated: true)
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "manager" {
            let statusVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "JobStatusVC") as! JobStatusVC
            self.navigationController?.pushViewController(statusVC, animated: true)

        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "supervisor"{
            
            let statusVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "AssetRequestVC") as! AssetRequestVC
            self.navigationController?.pushViewController(statusVC, animated: true)

        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "storekeeper"{
            let statusVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SupervisorInfoListVC") as! SupervisorInfoListVC
            self.navigationController?.pushViewController(statusVC, animated: true)

        }
}
}
