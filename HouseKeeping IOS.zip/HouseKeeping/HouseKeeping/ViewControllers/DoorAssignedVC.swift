//
//  DoorAssignedVC.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class DoorAssignedVC: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    var selectedJobId = ""
    var selectedFloor = ""
    
    var classRoom = ["Classroom 1-5", "Classroom 6-10", "Classroom 11-15", "Classroom 16-25", "Restroom", "Staffroom", "Laboratory"]
  //  @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        tableView.delegate = self
        tableView.dataSource = self
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }
    


}

extension DoorAssignedVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "SuperClassRoomCell", for: indexPath) as! SuperClassRoomCell
        cell.classRoom.text = classRoom[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return classRoom.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SelectUserVC") as! SelectUserVC
        viewController.selectedClassroom = classRoom[indexPath.row]
        viewController.selectedJobId = selectedJobId
        viewController.selectedFloor = selectedFloor
        self.navigationController?.pushViewController(viewController, animated: true)
    }

    
}
