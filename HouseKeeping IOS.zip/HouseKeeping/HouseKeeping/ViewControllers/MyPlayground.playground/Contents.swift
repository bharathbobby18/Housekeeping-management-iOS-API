import UIKit

let numbers = [1, 2, 3, 4, 5]
let doubledNumbers = numbers.map { $0 * 2 }
print(doubledNumbers) // Output: [2, 4, 6, 8, 10]


let strings = ["1", "2", "three", "4", "five"]
let validNumbers = strings.compactMap { Float($0) }
print(validNumbers) // Output: [1, 2, 4]


let nestedArrays = [[1, 2], [3, 4], [5, 6], ["7", "8"]]
let flatMap = nestedArrays.flatMap { $0 }
print(flatMap)


let names = ["Alice", "Bob", "Charlie"]
names.forEach { name in
    print(name,"!")
   }

let fruits = ["apple", "banana", "cherry"]
let hasBanana = fruits.contains("banana")
print(hasBanana) // Output: true


let sentence = "Hello, World!"
let words = sentence.split(separator: ",")
print(words) // Output: ["Hello,", "World!"]
