//
//  SelectProfileVC.swift
//  HouseKeeping
//
//  Created by SAIL on 13/10/23.
//

import UIKit

class SelectProfileVC: UIViewController {
    
    
    @IBOutlet weak var delWorkerView: UIView!
    @IBOutlet weak var addWorkerView: UIView!
    @IBOutlet weak var addWorkerLbl: UILabel!
    @IBOutlet weak var delete: UILabel!
    var addWorker = String()
    var deleteWorker = String()
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad();back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        delete.text =  deleteWorker
        addWorkerLbl.text = addWorker
        UserDefaultsManager.shared.setValue(deleteWorker, forKey: "DeleteEmployee")
        UserDefaultsManager.shared.setValue(addWorker, forKey: "AddEmployee")

        
        delWorkerView.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "supervisorlistVC") as! supervisorlistVC
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        addWorkerView.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "AddEmployeeVC") as! AddEmployeeVC
            self.navigationController?.pushViewController(nextVc, animated: true)
        }

  
    }
    

}
