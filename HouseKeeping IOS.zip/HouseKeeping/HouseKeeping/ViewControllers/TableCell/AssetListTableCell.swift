//
//  AssetListTableCell.swift
//  HouseKeeping
//
//  Created by SAIL on 28/10/23.
//

import UIKit

class AssetListTableCell: UITableViewCell {

    @IBOutlet weak var assetID_Lbl: UILabel!
    @IBOutlet weak var assetName_Lbl: UILabel!
    
    @IBOutlet weak var assetQty_Lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
