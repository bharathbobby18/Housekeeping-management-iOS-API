//
//  AssetRequestVC.swift
//  HouseKeeping
//
//  Created by SAIL on 10/10/23.
//

import UIKit

struct AssetReqDetails {
    var assest_id: Int
    var assestQty: Int
}



class AssetRequestVC: UIViewController {

    @IBOutlet weak var assertTableView: UITableView! {
        didSet{
            assertTableView.delegate = self
            assertTableView.dataSource = self
        }
    }
    
    var asserts: AssetsRequests!
    var assetReqData : AssestRequestedModel!
    var assetReqListDetails: [AssetReqDetails] = []

    
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAssertReqAPI()
    }
    
    func getAssertReqAPI() {
        APIHandler().getAPIValues(type: AssetsRequests.self, apiUrl: ServiceAPI.assert, method: "GET") { result in
            switch result {
            case .success(let data):
                self.asserts = data
                print(self.asserts.assets ?? "")
                print(self.asserts.assets?.count ?? 0)
                DispatchQueue.main.async {
                    self.assertTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func PostReqAssetAPI(assetReqListDetails: [HouseKeeping.AssetReqDetails]) {
        print(assetReqListDetails)
        let bioId = ServiceAPI.bioId

        // Constructing the assetReqListDetails dynamically
        var assetDetailsArray: [[String: Any]] = []
        for assetDetail in assetReqListDetails {
            let detail: [String: Any] = [
                "asset_id": assetDetail.assest_id,
                "request_quantity": assetDetail.assestQty
            ]
            assetDetailsArray.append(detail)
        }

        let requestBody: [String: Any] = [
            "bio_id": bioId,
            "assetReqListDetails": assetDetailsArray
        ]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: requestBody)

            APIHandler().postAPIRawJSON(type: AssestRequestedModel.self, apiUrl: ServiceAPI.assetReqtd, method: "POST", jsonData: jsonData) { result in
                switch result {
                case .success(let data):
                    self.assetReqData = data
                    DispatchQueue.main.async {
                        self.popUpAlert(title: "Success", message: "Asset Has been Requested", actionTitles: ["Done"], actionStyle: [.default]) { actions in
                            if actions[0].style == .default {
                                print("Ok button tapped")
                                let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                                self.navigationController?.pushViewController(nextV, animated: true)
                            }
                        }
                    }
                    print(data)
                    // assest Has been Requested
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        self.popUpAlert(title: "Failed", message: "Asset Request Has beed Failed", actionTitles: ["Done"], actionStyle: [.destructive]) { actions in
                            if actions[0].style == .default {
                                print("Ok button tapped")
                            }
                        }
                    }
                }
            }
        } catch {
            print(error)
        }
    }





    
    
    @IBAction func uploadbtn(_ sender: Any) {
        
        PostReqAssetAPI(assetReqListDetails: assetReqListDetails)
//        let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
//        self.navigationController?.pushViewController(nextV, animated: true)
        
    }
    func updateAssetReqListDetails(index: Int, quantity: Int) {
        if let assetIDString = asserts?.assets?[index].assetID {
            // Attempt to convert the string to an Int, use 0 as a default if conversion fails
            if let assetID = Int(assetIDString) {
                let roundedQuantity = Int(round(Double(quantity)))

                if roundedQuantity > 0 {
                    // If quantity is greater than 0, update or add the AssetReqDetails
                    if index < assetReqListDetails.count {
                        assetReqListDetails[index].assestQty = roundedQuantity
                    } else {
                        let newAssetReqDetail = AssetReqDetails(assest_id: assetID, assestQty: roundedQuantity)
                        assetReqListDetails.append(newAssetReqDetail)
                    }
                } else {
                    // If quantity is 0, remove the corresponding AssetReqDetails
                    if index < assetReqListDetails.count {
                        assetReqListDetails.remove(at: index)
                    }
                }
            } else {
                // Handle the case where the conversion fails (e.g., assetIDString is not a valid integer)
                print("Error: Unable to convert assetID to Int")
            }
        }
    }





}

extension AssetRequestVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return asserts?.assets?.count ?? 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = assertTableView.dequeueReusableCell(withIdentifier: "AssertTableViewCell", for: indexPath) as! AssertTableViewCell

        // Remove the closureActions and use addTarget for UIStepper
        cell.addMinus.addTarget(self, action: #selector(stepperValueChanged(_:)), for: .valueChanged)
        cell.addMinus.tag = indexPath.row  // Set the tag to identify the row

        if let assert = self.asserts?.assets?[indexPath.row] {
            cell.assetId.text = "\(assert.assetID ?? "")"
            cell.assetName.text = "\(assert.assetName ?? "")"
            cell.inStock.text = "\(assert.assetQuantity ?? "")"
        } else {
            cell.assetId.text = "Nil"
            cell.assetName.text = "Nil"
        }

        return cell
    }

    // Add a target-action method to handle UIStepper value change
    @objc func stepperValueChanged(_ sender: UIStepper) {
        let rowIndex = sender.tag
        let stepperValue = Int(sender.value)

        // Update the corresponding cell's quantity label and the data model
        if let cell = assertTableView.cellForRow(at: IndexPath(row: rowIndex, section: 0)) as? AssertTableViewCell {
            cell.qtyLbl.text = "\(stepperValue)"
            updateAssetReqListDetails(index: rowIndex, quantity: stepperValue)
        }
    }


}
    
//
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let cell = assertTableView.dequeueReusableCell(withIdentifier: "AssertTableViewCell", for: indexPath) as! AssertTableViewCell
//
//
//    }
//}
