//
//  AssetReequestVC.swift
//  HouseKeeping
//
//  Created by SAIL on 24/10/23.
//

import UIKit



class AssetReequestVC: UIViewController {

    @IBOutlet weak var assetListTable: UITableView! {
        didSet {
            assetListTable.delegate = self
            assetListTable.dataSource = self
        }
    }
    var bioID = String()
    var assetListData : AssetListDetailsModel? {
        didSet {
            if let assetListData = assetListData {
                print(assetListData)
            }
            else {
                print("No Data Available")
            }
        }
    }
    
    @IBOutlet weak var back: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        self.ShowAssetDetails()
        print("bioID ; \(bioID)")
 
    }
    @IBAction func accecptRequest(_ sender: Any) {
         self.popUpAlert(title: "Success", message: "Asset Request Has been Approved", actionTitles: ["Done"], actionStyle: [.default]) { actions in
             if actions[0].style == .default {
                 print("Ok button tapped")
                 let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                 self.navigationController?.pushViewController(nextV, animated: true)
             }
         }
//        PostAssetAcceptAPI()
//         GetAssetAcceptAPI()
    }
     
     func GetAssetAcceptAPI() {
          APIHandler().getAPIValues(type: SuccessMsgModel.self, apiUrl: "\(ServiceAPI.ipAddress)house1/reqacceptbtn.php?bio_id=\(bioID)", method: "GET") { result in
               switch result {
               case.failure(let error):
                   print(error)
               case.success(let data):
                   print(data)
                   DispatchQueue.main.async {
                       
                   
                  if data.success == true{
                       self.popUpAlert(title: "Success", message: "Asset Request Has been Approved", actionTitles: ["Done"], actionStyle: [.default]) { actions in
                           if actions[0].style == .default {
                               print("Ok button tapped")
                               let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                               self.navigationController?.pushViewController(nextV, animated: true)
                           }
                       }
                  }else{
                      print("error")
                  }
                   }
                   
               }
          }
     }
    
    func PostAssetAcceptAPI(){
        let params : [String : String] = ["bio_id": "=\(bioID)"]
        print(ServiceAPI.acptAssetDetails)
        print(params)
        
         APIHandler().postAPIValues(type: SuccessMsgModel.self, apiUrl: "\(ServiceAPI.ipAddress)house1/reqacceptbtn.php?bio_id=\(bioID)", method: "POST", formData: params) { Result in
            switch Result {
                
            case.failure(let error):
                print(error)
            case.success(let data):
                print(data)
                DispatchQueue.main.async {
                    
                
               if data.success == true{
                    self.popUpAlert(title: "Success", message: "Asset Request Has been Approved", actionTitles: ["Done"], actionStyle: [.default]) { actions in
                        if actions[0].style == .default {
                            print("Ok button tapped")
                            let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                            self.navigationController?.pushViewController(nextV, animated: true)
                        }
                    }
               }else{
                   print("error")
               }
                }
                
            }
        }
    }
    
    
    func ShowAssetDetails(){
        APIHandler().getAPIValues(type: AssetListDetailsModel.self, apiUrl: "\(ServiceAPI.assetListDetails)bio_id=\(bioID)", method: "GET") { Result in
            switch Result {
            case.success(let data):
                print(data)
                self.assetListData = data
                DispatchQueue.main.async {
                    self.assetListTable.reloadData()
                }
            case.failure(let error):
                print(error)
                
            }
        }
    }


}

extension AssetReequestVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return assetListData?.data?.count ?? 0
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = assetListTable.dequeueReusableCell(withIdentifier: "AssetListTableCell") as! AssetListTableCell
        cell.assetID_Lbl.text = assetListData?.data?[indexPath.row].assetID ?? ""
        cell.assetQty_Lbl.text = assetListData?.data?[indexPath.row].requestQuantity ?? ""
        cell.assetName_Lbl.text = assetListData?.data?[indexPath.row].assetName ?? ""
        return cell
    }
}
