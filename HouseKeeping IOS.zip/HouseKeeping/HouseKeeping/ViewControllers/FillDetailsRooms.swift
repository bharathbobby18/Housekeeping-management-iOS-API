//
//  FillDetailsRooms.swift
//  HouseKeeping
//
//  Created by SAIL on 13/10/23.
//

import UIKit

class FillDetailsRooms: UIViewController {

    @IBOutlet weak var buildingName: UITextField!
    @IBOutlet weak var roomNo: UITextField!
    @IBOutlet weak var floorNo: UITextField!
    
    @IBOutlet weak var roomTypeBtn: UIButton!
    
    

    @IBOutlet weak var back: UIImageView!
    var success : SucessModel!
    var selectedButton: UIButton?
    var roomType = String()
    var key = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        


        }
    @IBAction func radio(_ sender: UIButton) {
        let selectedButton = sender.tag

        // Set all buttons to the "radio_Off" image
        for i in 1...5 {
            if let button = view.viewWithTag(i) as? UIButton {
                button.setImage(UIImage(named: "radio_Off"), for: .normal)
            }
        }

        // Set the selected button to "radio_On"

        // Now, you can perform actions based on the selected button
        switch selectedButton {
        case 5:
            sender.setImage(UIImage(named: "radio_On"), for: .normal)
            roomType = "Class Room"
            print(roomType, "case 5")
        case 1:
            sender.setImage(UIImage(named: "radio_On"), for: .normal)
            roomType = "Staff Room"
            print(roomType, "case 1")
        case 2:
            sender.setImage(UIImage(named: "radio_On"), for: .normal)
            roomType = "Laboratory"
            print(roomType, "case 2")
        case 3:
            sender.setImage(UIImage(named: "radio_On"), for: .normal)
            roomType = "Office Room"
            print(roomType, "case 3")
        case 4:
            sender.setImage(UIImage(named: "radio_On"), for: .normal)
            roomType = "Rest Room"
            print(roomType, "case 4")
        default:
            return
        }
    }



 
    @IBAction func submit(_ sender: Any) {
        AddBuildingDetails()

    }
    
    
    func AddBuildingDetails() {
        let apiURL = "http://192.168.30.40//house1/addbul.php"
        
        let parameters: [String: String] = [
            "buildingname": buildingName.text ?? "",
            "floor_no": floorNo.text ?? "",
            "room_no": roomNo.text ?? "",
            "room_type": roomType,
            "building_id" : ""
        ]
        APIHandler().postAPIValues(type: SucessModel.self, apiUrl: ServiceAPI.addBill, method: "POST", formData: parameters) { Result in
            switch Result {
            case .success(let data):
                print(data)
                if data.status == true {
                    DispatchQueue.main.async {
                        self.popUpAlert(title: "", message: data.message ?? "", actionTitles: ["Done"], actionStyle: [.default]) { actions in
                                if actions[0].style == .default {
                                    print("Ok button tapped")
                                    for controller in self.navigationController!.viewControllers as Array {
                                        if controller.isKind(of: TabbarVC.self) {
                                            self.navigationController!.popToViewController(controller, animated: true)
                                            break
                                        }
                                    }
                                }
                            }
                        }
                    }

                else if data.status == false {
                    print("Error")
                    self.popUpAlert(title: "", message: data.message ?? "", actionTitles: ["Ok" ], actionStyle: [.destructive]) { actions in
                            if actions[0].style == .destructive {
                                print("Ok button tapped")
                                // Add your logic for the OK button action here
                            } else {
                                print("Cancel button tapped")
                                // Add your logic for the Cancel button action here
                            }
                        }
                }

            case .failure(let error):
                print(error)
                
            }
        }
    }

}
