//
//  AddEmployeeVC.swift
//  HouseKeeping
//
//  Created by SAIL on 17/10/23.
//

import UIKit

class AddEmployeeVC: UIViewController {

    @IBOutlet weak var headerLbl: UILabel!
    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var contact: UITextField!
    @IBOutlet weak var bioId: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var qualiTF: UITextField!
    @IBOutlet weak var designation: UITextField!
    var date = String()
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        AddEmployeeData()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(datePickerValueChanged), for: .valueChanged)
    }
@objc func datePickerValueChanged() {
    let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "yyyy-MM-dd" // Set the desired date format
     
     let selectedDate = datePicker.date
     date = dateFormatter.string(from: selectedDate)
    print(date)
}
    
    @IBAction func addAction(_ sender: Any) {
        if firstNameTF.text?.isEmpty ?? true ||
              lastNameTF.text?.isEmpty ?? true ||
              email.text?.isEmpty ?? true ||
              contact.text?.isEmpty ?? true ||
              bioId.text?.isEmpty ?? true ||
              password.text?.isEmpty ?? true ||
              qualiTF.text?.isEmpty ?? true ||
            designation.text?.isEmpty ?? true {
            popUpAlert(title: "Warrning", message: "Enter Required Details", actionTitles: ["Ok"], actionStyle: [.destructive]) { actions in
                       if actions[0].style == .destructive {
                           print("Ok button tapped")
                           // Add your logic for the OK button action here
                       } else {
                           print("Cancel button tapped")
                           // Add your logic for the Cancel button action here
                       }
                   }
        }
        else {
            AddEmpPostMethod()

        }
        
        
    }
    
    
    
    
    func AddEmployeeData() {
        if let DelEmp : String = UserDefaultsManager.shared.getValue(forKey: "AddEmployee"){
            if DelEmp == "Add Manager" { // Add Manager
                designation.text = "manager"
                headerLbl.text =  "Fill the details of Manager"
            }
            else if DelEmp == "Add Worker" {
                designation.text = "worker"
                headerLbl.text =  "Fill the details of Worker"

            }
            else if DelEmp == "Add Supervisor" {
                designation.text = "supervisor"
                headerLbl.text =  "Fill the details of Supervisor"
            }

            }
        }
    
    func AddEmpPostMethod() {
        let formData : [String : String] = [
            "firstName": firstNameTF.text ?? "",
            "lastName" : lastNameTF.text ?? "",
            "email" : email.text ?? "",
            "birthday" : self.date,
            "contact" : contact.text ?? "",
            "bio_id" : bioId.text ?? "",
            "password" : password.text ?? "",
            "Designation" : designation.text ?? "",
            "qualification" : qualiTF.text ?? ""
        ]
 
        APIHandler().postAPIValues(type: SucessModel.self, apiUrl: ServiceAPI.addEmpSuccess, method: "POST", formData: formData) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.popUpAlert(title: "Registration", message: "User Added Successfully", actionTitles: ["Ok"], actionStyle: [.destructive]) { actions in
                               if actions[0].style == .destructive {
                                   print("Ok button tapped")
                                   let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                                   self.navigationController?.pushViewController(nextV, animated: true)
                                   // Add your logic for the OK button action here
                               } else {
                                   print("Cancel button tapped")
                                   // Add your logic for the Cancel button action here
                               }
                           }
                }
                print(data)
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    self.popUpAlert(title: "Warrning", message: "User Registration Failed", actionTitles: ["Ok"], actionStyle: [.destructive]) { actions in
                               if actions[0].style == .destructive {
                                   print("Ok button tapped")
                                   let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                                   self.navigationController?.pushViewController(nextV, animated: true)
                                   // Add your logic for the OK button action here
                               } else {
                                   print("Cancel button tapped")
                                   // Add your logic for the Cancel button action here
                               }
                           }
                }
            }
        }
    }
    
    @IBAction func addbtn(_ sender: Any) {
        
        let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        self.navigationController?.pushViewController(nextV, animated: true)
        
    }
}
   

