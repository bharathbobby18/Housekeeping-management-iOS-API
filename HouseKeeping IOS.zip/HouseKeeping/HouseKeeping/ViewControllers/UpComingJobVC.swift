//
//  UpComingJobVC.swift
//  HouseKeeping
//
//  Created by SAIL on 24/10/23.
//

import UIKit

class UpComingJobVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
