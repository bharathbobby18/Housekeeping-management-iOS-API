//
//  FloorAssignedVC.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class FloorAssignedVC: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    //@IBOutlet weak var back: UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        tableView.delegate = self
        tableView.dataSource = self
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        
    }
}


extension FloorAssignedVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "tabCell", for: indexPath) as! FloorTableViewCell
      
        cell.lblFloor.text = "Ground Floor Build"
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        10
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "DoorAssignedVC") as! DoorAssignedVC
         self.navigationController?.pushViewController(viewController, animated: true)
    }

    
}
