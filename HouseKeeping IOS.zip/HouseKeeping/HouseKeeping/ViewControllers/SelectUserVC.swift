//
//  SelectUserVC.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class SelectUserVC: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    var selectedCellIndices = [IndexPath]()
    var selectedClassroom = ""
    var selectedJobId = ""
    var selectedFloor = ""

    var workerData : WorkerModel? {
        didSet{
            if let workerData = workerData {
                print(workerData)
            }
            else {print("No Data Available")}
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        print(selectedFloor,selectedJobId,selectedClassroom)
        self.WorkerList()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        tableView.delegate = self
        tableView.dataSource = self
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }

    @IBAction func ContinueAc(_ sender: Any) {
        
        let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "JobScheduledVC") as! JobScheduledVC
        viewController.message = "Job as Been Scheduled"
        self.navigationController?.pushViewController(viewController, animated: true)
        
    }
    
    func WorkerList(){
        APIHandler().getAPIValues(type: WorkerModel.self, apiUrl: ServiceAPI.workerList, method: "GET") { Result in
            switch Result {
            case.success(let data):
                print(data)
                self.workerData = data
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension SelectUserVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return workerData?.data?.count ?? 0
        
    }


    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userCell", for: indexPath) as! UserTableViewCell

        if let workers = workerData?.data, indexPath.row < workers.count {
            let worker = workers[indexPath.row]
            cell.userNameLbl.text = worker.firstName

            // Check if the current cell's index is in the selectedCellIndices
            if selectedCellIndices.contains(indexPath) {
                cell.radioBtn.setImage(UIImage(named: "radio_On"), for: .normal)
            } else {
                cell.radioBtn.setImage(UIImage(named: "radio_Off"), for: .normal)
            }

            // Add a tap action to the radio button
            cell.radioBtn.addAction(for: .tap) { [weak self] in
                guard let self = self else { return }
                // Toggle the selection for the tapped cell
                if let index = self.selectedCellIndices.firstIndex(of: indexPath) {
                    self.selectedCellIndices.remove(at: index)
                } else {
                    self.selectedCellIndices.append(indexPath)
                }

                // Reload only the tapped cell to update its radio button image
                tableView.reloadRows(at: [indexPath], with: .none)
            }
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}

