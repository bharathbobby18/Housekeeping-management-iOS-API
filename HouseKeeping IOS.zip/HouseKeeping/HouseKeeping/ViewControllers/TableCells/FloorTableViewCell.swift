//
//  FloorTableViewCell.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class FloorTableViewCell: UITableViewCell {

    @IBOutlet weak var lblFloor: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
