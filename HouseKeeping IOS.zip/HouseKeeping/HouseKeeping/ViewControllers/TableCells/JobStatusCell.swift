//
//  JobStatusCell.swift
//  HouseKeeping
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class JobStatusCell: UITableViewCell {

    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var fromDate: UILabel!
    @IBOutlet weak var toDate: UILabel!
    @IBOutlet weak var floor: UILabel!
    @IBOutlet weak var jobId: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
