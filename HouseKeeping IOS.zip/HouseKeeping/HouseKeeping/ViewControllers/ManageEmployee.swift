//
//  ManageEmployee.swift
//  HouseKeeping
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class ManageEmployee: UIViewController {

    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    
    
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        super.viewDidLoad();back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        view1.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SelectProfileVC") as! SelectProfileVC
            let worker = "Add Supervisor" 
            let delWorker = "Delete Supervisor"
            nextVc.addWorker = worker
            nextVc.deleteWorker = delWorker
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        view2.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SelectProfileVC") as! SelectProfileVC
            let worker = "Add Worker"
            let delWorker = "Delete Worker"
            nextVc.addWorker = worker
            nextVc.deleteWorker = delWorker
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        view3.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SelectProfileVC") as! SelectProfileVC
            let worker = "Add Manager"
            let delWorker = "Delete Manager"
            nextVc.addWorker = worker
            nextVc.deleteWorker = delWorker
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        
    }

}
