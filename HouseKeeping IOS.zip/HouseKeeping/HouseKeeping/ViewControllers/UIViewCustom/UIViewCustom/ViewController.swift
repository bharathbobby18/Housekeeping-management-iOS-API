//
//  ViewController.swift
//  UIViewCustom
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var uiview: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let ellipseView = EllipseView(frame: CGRect(x: 50, y: 50, width: 200, height: 100))
           ellipseView.topColor = UIColor.red
           ellipseView.bottomColor = UIColor.blue
           self.uiview.addSubview(ellipseView)
        }
    }




class EllipseView: UIView {
    var topColor: UIColor = UIColor.red
    var bottomColor: UIColor = UIColor.blue

    override func draw(_ rect: CGRect) {
        let path = UIBezierPath(ovalIn: rect)

        // Split the ellipse into top and bottom parts
        let centerY = rect.origin.y + rect.size.height / 2
        let topRect = CGRect(x: rect.origin.x, y: rect.origin.y, width: rect.size.width, height: centerY - rect.origin.y)
        let bottomRect = CGRect(x: rect.origin.x, y: centerY, width: rect.size.width, height: rect.size.height - (centerY - rect.origin.y))

        // Set the top and bottom fill colors
        topColor.setFill()
        path.append(UIBezierPath(ovalIn: topRect))
        path.fill()
        
        bottomColor.setFill()
        path.append(UIBezierPath(ovalIn: bottomRect))
        path.fill()
    }
}


