//
//  AssignJobVC.swift
//  HouseKeeping
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class AssignJobVC: UIViewController {

    @IBOutlet weak var floorNo: UITextField!
    @IBOutlet weak var supervisorTF: UITextField!
    @IBOutlet weak var toDate: UIDatePicker!
    @IBOutlet weak var fromDate: UIDatePicker!
    @IBOutlet weak var dropDownImg: UIImageView!
    
    
    var selectedDatePicker: UIDatePicker? // To track the selected date picker
    var fromDateValue = String()
    var toDateValue = String()
    var employee: EmployeeModel!

    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        dropDownImg.addAction(for: .tap) {
            self.SupervisorListAPI()
        }
        
        toDate.datePickerMode = .date
        fromDate.datePickerMode = .date
        toDate.addTarget(self, action: #selector(datePickerValueChanged), for: .valueChanged)
        fromDate.addTarget(self, action: #selector(datePickerValueChanged), for: .valueChanged)
    }
    override func viewWillAppear(_ animated: Bool) {
        getSupervisorAPI()
    }

    @objc func datePickerValueChanged(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Set the desired date format
        
        let selectedDate = sender.date
        let formattedDate = dateFormatter.string(from: selectedDate)
        
        if sender == toDate {
            toDateValue = formattedDate
        } else if sender == fromDate {
            fromDateValue = formattedDate
        }
        
        print("From Date: \(fromDateValue), To Date: \(toDateValue)")
    }
    
    @IBAction func assign(_ sender: Any) {
        AssignJob()
    }
    

    func AssignJob(){
        let formData : [String : String] = ["from":fromDateValue,
                                            "to": toDateValue,
                                            "floor_no": floorNo.text ?? "",
                                            "supervisor" : supervisorTF.text ?? ""]
        APIHandler().postAPIValues(type: SucessModel.self, apiUrl: ServiceAPI.managerAssignJob, method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    
                    let nextVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "JobScheduledVC") as! JobScheduledVC
                    nextVC.message = data.message ?? ""
                    
                    self.navigationController?.pushViewController(nextVC, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getSupervisorAPI(){
        
        APIHandler().getAPIValues(type: EmployeeModel.self, apiUrl: ServiceAPI.supervisorList, method: "GET") { result in
            switch result {
            case .success(let data):
                self.employee = data
                print(self.employee.data ?? "")
                print(self.employee.data?.count ?? 0)
            case .failure(let error):
                print(error)
            }
        }
    }
    func SupervisorListAPI() {
        let actionSheetAlertController: UIAlertController = UIAlertController(title: nil, message: "Select", preferredStyle: .actionSheet)

        if let employeeData = employee.data, !employeeData.isEmpty {
            for n in 0..<employeeData.count {
                if let firstName = employeeData[n].firstName {
                    let action = UIAlertAction(title: firstName, style: .default) { (action) in
                        print("Selected First Name: \(firstName)")
                        self.supervisorTF.text = firstName
                    }
                    action.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
                    action.setValue(UIColor.black, forKey: "titleTextColor")
                    actionSheetAlertController.addAction(action)
                }
            }
        } else {
            print("No data available")
        }

        let cancelActionButton = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        actionSheetAlertController.addAction(cancelActionButton)

        if let popoverController = actionSheetAlertController.popoverPresentationController {
            popoverController.sourceView = self.view
            popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            popoverController.permittedArrowDirections = []
        }

        self.present(actionSheetAlertController, animated: true, completion: nil)
    }

    
}
