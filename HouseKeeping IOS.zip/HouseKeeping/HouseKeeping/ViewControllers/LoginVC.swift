//
//  ViewController.swift
//  HouseKeeping
//
//  Created by SAIL on 11/09/23.
//

import UIKit

class LoginVC : UIViewController {
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var topview: UIView!
    
    @IBOutlet weak var back: UIImageView!
    var logiAPI : LoginModel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.userName.text = "192011035"
       // self.password.text = "sony123"
        
                self.navigationController?.isNavigationBarHidden = true
//                self.tabBarController?.tabBar.isHidden = false
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        SelectedProfileLogin()
    }
    @IBAction func loginAc(_ sender: Any) {
        if password.text == "" && userName.text == "" {
            self.popUpAlert(title: "Enter", message: "Username and Password", actionTitles: ["Ok"], actionStyle: [.destructive]) { actions in
                if actions[0].style == .destructive {
                    print("Ok button tapped")
                    // Add your logic for the OK button action here
                } else {
                    print("Cancel button tapped")
                    // Add your logic for the Cancel button action here
                }
            }
        }
        else {
            GetLoginAPI()
        }
    }
    
    
    func SelectedProfileLogin(){
        if UserDefaultsManager.shared.getValue(forKey: "Profile") == "admin" {
            userName.placeholder = "Admin"
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "manager" {
            userName.placeholder = "Manager"
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "supervisor"{
            userName.placeholder = "Supervisor"
        }
        else if UserDefaultsManager.shared.getValue(forKey: "Profile") == "storekeeper"{
            userName.placeholder = "Storekeeper"
        }
    }
    
    func GetLoginAPI() {
        APIHandler().getAPIValues(type: LoginModel.self, apiUrl: "\(ServiceAPI.login)email=\(userName.text ?? "")&pass=\(password.text ?? "")&type=\(UserDefaultsManager.shared.getValue(forKey: "Profile") ?? "")", method: "GET") { result  in
            switch result {
            case .success(let data):
                if data.status == true {
                    let profile = data.data.designation
                    let name = data.data.firstName

                    UserDefaultsManager.shared.setValue(name, forKey: "FirstName")

                    UserDefaultsManager.shared.setValue(profile, forKey: "Profile")
                    DispatchQueue.main.async {
                        ServiceAPI.bioId = self.userName.text ?? ""
                        let viewController = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                        viewController.designation = profile
//                        viewController.name2 = "Manage Rooms"
                        self.navigationController?.pushViewController(viewController, animated: true)
                    }

                }
                else if data.status == false {
                    self.popUpAlert(title: "Warnning", message: "Incorrect Password", actionTitles: ["Ok"], actionStyle: [.destructive]) { actions in
                        if actions[0].style == .destructive {
                            print("Ok button tapped")
                            // Add your logic for the OK button action here
                        } else {
                            print("Cancel button tapped")
                            // Add your logic for the Cancel button action here
                        }
                    }
                }
                print(data)
            case .failure(let error):
                DispatchQueue.main.async {

                self.popUpAlert(title: "Login Failed", message: "Please Check Your Bio ID & Password ", actionTitles: ["Ok"], actionStyle: [.destructive]) { actions in
                    if actions[0].style == .destructive {
                        print("Ok button tapped")
                        // Add your logic for the OK button action here
                    } else {
                        print("Cancel button tapped")
                        // Add your logic for the Cancel button action here
                    }
                }
                    
                print(error)
                }
            }
        }
    }
    
}


