//
//  AssetRequestList.swift
//  HouseKeeping
//
//  Created by SAIL on 24/10/23.
//

import UIKit

class AssetRequestList: UIViewController {

    @IBOutlet weak var assetList: UITableView! {
        didSet {
            assetList.delegate = self
            assetList.dataSource = self
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    



}


extension AssetRequestList : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = assetList.dequeueReusableCell(withIdentifier: "AssetsRequestListCell") as! AssetsRequestListCell
        
        return cell
    }
}


