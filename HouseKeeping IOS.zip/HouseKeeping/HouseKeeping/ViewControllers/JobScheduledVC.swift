//
//  JobScheduledVC.swift
//  HouseKeeping
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class JobScheduledVC: UIViewController {

    
    @IBOutlet weak var successLbl: UILabel!
    var message = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        successLbl.text = message
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//            for controller in self.navigationController!.viewControllers as Array {
//                if controller.isKind(of: HomeViewController.self) {
//                    self.navigationController!.popToViewController(controller, animated: true)
//                    break
//                }
//            }
            let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            self.navigationController?.pushViewController(nextV, animated: true)
        }
    }

}
