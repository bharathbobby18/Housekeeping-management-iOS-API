//
//  supervisor.swift
//  HouseKeeping
//
//  Created by SAIL on 14/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct EmployeeModel: Codable {
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var firstName, bioID: String?

    enum CodingKeys: String, CodingKey {
        case firstName
        case bioID = "bio_id"
    }
}

