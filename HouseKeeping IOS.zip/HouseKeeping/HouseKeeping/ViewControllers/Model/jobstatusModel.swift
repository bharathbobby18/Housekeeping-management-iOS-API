//
//  jobstatusModel.swift
//  HouseKeeping
//
//  Created by SAIL on 18/10/23.
//

import Foundation

struct JobStatusModel: Codable {
    var data: [JobStatusItem]?
}

struct JobStatusItem: Codable {
    var jobID: String?
    var fromDate: String
    var toDate: String
    var floorNo: String
    var supervisor: String
    var status: String
    var image: String
    
    enum CodingKeys: String, CodingKey {
        case jobID = "job_id"
        case fromDate = "from_date"
        case toDate = "to_date"
        case floorNo = "floor_no"
        case supervisor = "supervisor"
        case status = "status"
        case image = "image"
    }

}
