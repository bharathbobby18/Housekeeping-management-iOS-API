//
//  LoginModel.swift
//  HouseKeeping
//
//  Created by SAIL on 11/10/23.

import Foundation

// MARK: - Welcome
struct LoginModel: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let bioID, firstName, lastName, email: String
    let qualification, designation, contact, password: String
    let birthday: String

    enum CodingKeys: String, CodingKey {
        case bioID = "bio_id"
        case firstName, lastName, email, qualification
        case designation = "Designation"
        case contact, password, birthday
    }
}
