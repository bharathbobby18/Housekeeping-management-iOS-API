//
//  JobStatusVC.swift
//  HouseKeeping
//
//  Created by SAIL on 18/10/23.
//

import UIKit


class JobStatusVC: UIViewController {
    
    @IBOutlet weak var segmentOt: UISegmentedControl!
    @IBOutlet weak var jobList: UITableView!{
        didSet {
            jobList.delegate = self
            jobList.dataSource = self
        }
    }
    var nSelectedSegmentIndex : Int = 1
    var status: JobStatusModel? {
        didSet {
            if let status = status {
                print(status)
            }
            else {print("No Data Available")}
        }
    }

    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad();back.addAction(for: .tap) {
            let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            self.navigationController?.pushViewController(nextV, animated: true)        }
        
        JobStatusAPI()
        
    }
    
    @IBAction func segmentAc(_ sender: Any) {
        switch segmentOt.selectedSegmentIndex {
        case 0:
            self.nSelectedSegmentIndex = 1
            jobList.reloadData()
            print("nSelectedSegmentIndex == 1")

        case 1:
            self.nSelectedSegmentIndex = 2
            jobList.reloadData()
            print("nSelectedSegmentIndex == 2")

        default:
                print("")

        }
        
        
    }
    
    func JobStatusAPI() {
        APIHandler().getAPIValues(type: JobStatusModel.self, apiUrl: ServiceAPI.jobStatus, method: "GET") { Result in
            switch Result{
            case .success(let data):
                self.status = data
                print(self.status?.data )
//                print(self.status?.data[indexPath.row].toDate? ?? 0)
//              print(self.status?.floorNo?.count ?? 0)
              //print(self.status?.status ?? "")
                DispatchQueue.main.async {
                    self.jobList.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }

}

extension JobStatusVC : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        guard let supervisorHomeData = status, let jobs = supervisorHomeData.data else {
            return 0
        }
        if nSelectedSegmentIndex == 1 {
            // Count the number of "Pending" jobs
            return jobs.filter { $0.status == "Pending" }.count
        } else if nSelectedSegmentIndex == 2 {
            // Count the number of "Completed" jobs
            return jobs.filter { $0.status == "Completed" }.count
        }
        
        return status?.data?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = jobList.dequeueReusableCell(withIdentifier: "JobStatusCell") as! JobStatusCell
        
        guard let supervisorHomeData = status, let jobs = supervisorHomeData.data else {
            return cell
        }
//        let job = jobs[indexPath.row]
        if nSelectedSegmentIndex == 1 {
               let pendingJobs = jobs.filter { $0.status == "Pending" }
               
               if indexPath.row < pendingJobs.count {
                   let job = pendingJobs[indexPath.row]
                   cell.jobId.text = "\(job.jobID ?? "")"
                   cell.fromDate.text = "\(job.fromDate )"
                   cell.toDate.text = "\(job.toDate )"
                   cell.floor.text = "\(job.floorNo )"
                   cell.status.text = "\(job.status )"
               }
           }
        
        else if nSelectedSegmentIndex == 2 {
               let pendingJobs = jobs.filter { $0.status == "Completed" }
               
               if indexPath.row < pendingJobs.count {
                   let job = pendingJobs[indexPath.row]
                   cell.jobId.text = "\(job.jobID ?? "")"
                   cell.fromDate.text = "\(job.fromDate )"
                   cell.toDate.text = "\(job.toDate )"
                   cell.floor.text = "\(job.floorNo )"
                   cell.status.text = "\(job.status )"
               }
           }
        
        
//        else if nSelectedSegmentIndex == 2 && job.status == "Completed" {
//               cell.jobId.text = "\(job.jobID ?? "")"
//               cell.fromDate.text = "\(job.fromDate )"
//               cell.toDate.text = "\(job.toDate )"
//               cell.floor.text = "\(job.floorNo )"
//               cell.status.text = "\(job.status )"
//        }

        
//        if let statuss = self.status?.data?[indexPath.row] {
//            cell.jobId.text = "\(statuss.jobID ?? "")"
//            cell.fromDate.text = "\(statuss.fromDate )"
//            cell.toDate.text = "\(statuss.toDate )"
//            cell.floor.text = "\(statuss.floorNo )"
//            cell.status.text = "\(statuss.status )"
//        }
//        else {
//           cell.jobId.text = "Nil"
//           cell.fromDate.text = "Nil"
//           cell.toDate.text = "Nil"
//            cell.floor.text = "Nil"
//            cell.status.text = "Nil"
//        }
        return cell
    }
}
