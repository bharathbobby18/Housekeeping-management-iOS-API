//
//  AssertTableViewCell.swift
//  HouseKeeping
//
//  Created by SAIL on 10/10/23.
//

import UIKit

class AssertTableViewCell: UITableViewCell {

    @IBOutlet weak var inStock: UILabel!
    @IBOutlet weak var assetId: UILabel!
    @IBOutlet weak var assetName: UILabel!
    @IBOutlet weak var addMinus: UIStepper!
    @IBOutlet weak var qtyLbl: UILabel!
    
    
       @IBAction func stepperAction(_ sender: UIStepper) {
           
           self.qtyLbl.text = "\(Int(sender.value))"
       }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.qtyLbl.text = "0"
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    
    }

}
