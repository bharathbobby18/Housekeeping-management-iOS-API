//
//  SuperJobDetails.swift
//  HouseKeeping
//
//  Created by SAIL on 31/10/23.
//

import UIKit

class SuperJobDetails: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var jobId: UILabel!
    @IBOutlet weak var fromDate: UILabel!
    
    @IBOutlet weak var floorNo: UILabel!
    @IBOutlet weak var toDate: UILabel!
    var job_id = String()
    var from_Date = String()
    var to_Date = String()
    var floor_No = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        jobId.text = job_id
        fromDate.text = from_Date
        toDate.text = to_Date
        floorNo.text = floor_No
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

    }

    @IBAction func home(_ sender: Any) {
        
        let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        self.navigationController?.pushViewController(nextV, animated: true)
        
    }
}
