//
//  SupervisorHomeJobListVC.swift
//  HouseKeeping
//
//  Created by SAIL on 31/10/23.
//

import UIKit


class SupervisorHomeJobListVC: UIViewController {

    @IBOutlet weak var supervisorList: UITableView!{
        didSet {
            supervisorList.dataSource = self
            supervisorList.delegate = self
        }
    }
    @IBOutlet weak var segmentOt: UISegmentedControl!
    
    var nSelectedSegmentIndex : Int = 1
    var supervisorHomeData : SupervisorJobModel?{
        didSet{
            if let supervisorHomeDatas = supervisorHomeData {
                print(supervisorHomeDatas)
            }
            else {print("No Data Available")}
        }
    }
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        GetSupervisorHomeList()

        back.addAction(for: .tap) {
                let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
                self.navigationController?.pushViewController(nextV, animated: true)
            }
    }
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaultsManager.shared.getValue(forKey: "Profile") == "admin" {
            let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            self.navigationController?.pushViewController(nextV, animated: true)
        }
        if UserDefaultsManager.shared.getValue(forKey: "Profile") == "storekeeper" {
            let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
            self.navigationController?.pushViewController(nextV, animated: true)
        }
        
        
        if UserDefaultsManager.shared.getValue(forKey: "Profile") == "manager" {
            let nextV = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "JobStatusVC") as! JobStatusVC
            self.navigationController?.pushViewController(nextV, animated: true)
        }
    }
    
    @IBAction func segmentAc(_ sender: Any) {
        switch segmentOt.selectedSegmentIndex {
        case 0:
            self.nSelectedSegmentIndex = 1
            supervisorList.reloadData()
            print("nSelectedSegmentIndex == 1")

        case 1:
            self.nSelectedSegmentIndex = 2
            supervisorList.reloadData()
            print("nSelectedSegmentIndex == 2")

        default:
                print("")

        }
        
        
    }
    
    
    func GetSupervisorHomeList() {
        APIHandler().getAPIValues(type: SupervisorJobModel.self, apiUrl: "\(ServiceAPI.supervisorJob)bio_id=\(ServiceAPI.bioId)", method: "GET") { Result in
            switch Result {
            case .success(let data):
                print(data)
                self.supervisorHomeData = data
                DispatchQueue.main.async {
                    self.supervisorList.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    

}

extension SupervisorHomeJobListVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let supervisorHomeData = supervisorHomeData, let jobs = supervisorHomeData.jobs else {
            return 0
        }

        if nSelectedSegmentIndex == 1 {
            // Count the number of "Pending" jobs
            return jobs.filter { $0.status == "Pending" }.count
        } else if nSelectedSegmentIndex == 2 {
            // Count the number of "Completed" jobs
            return jobs.filter { $0.status == "Completed" }.count
        }

        return 0 // Handle other cases as needed
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SupervisorHomeListCel", for: indexPath) as! SupervisorHomeListCel

        guard let supervisorHomeData = supervisorHomeData, let jobs = supervisorHomeData.jobs else {
            return cell
        }

        let job = jobs[indexPath.row]

        if nSelectedSegmentIndex == 1 {
               let pendingJobs = jobs.filter { $0.status == "Pending" }
               
               if indexPath.row < pendingJobs.count {
                   let job = pendingJobs[indexPath.row]

                   // Add your logic here to customize the cell for each "Pending" job
                   cell.jobId.text = job.job_id ?? ""
                   cell.formDate.text = job.from_date ?? ""
                   cell.toDate.text = job.to_date ?? ""
                   cell.floorNo.text = job.floor_no ?? ""
               }
           } else if nSelectedSegmentIndex == 2 && job.status == "Completed" {
            // Populate the cell for "Completed" jobs
            cell.jobId.text = job.job_id ?? ""
            cell.formDate.text = job.from_date ?? ""
            cell.toDate.text = job.to_date ?? ""
            cell.floorNo.text = job.floor_no ?? ""
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let supervisorHomeData = supervisorHomeData, let jobs = supervisorHomeData.jobs else {
            return
        }
        let pendingJobs = jobs.filter { $0.status == "Pending" }
        
        if indexPath.row < pendingJobs.count {
            let job = pendingJobs[indexPath.row]
            let nextVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "SuperJobDetails") as! SuperJobDetails

            nextVC.job_id = job.job_id ?? ""
            nextVC.from_Date = job.from_date ?? ""
            nextVC.to_Date = job.to_date ?? ""
            nextVC.floor_No = job.floor_no ?? ""
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
    }

}











class SupervisorHomeListCel: UITableViewCell{
    @IBOutlet weak var jobId: UILabel!
    
    @IBOutlet weak var formDate: UILabel!
    
    @IBOutlet weak var toDate: UILabel!
    
    @IBOutlet weak var floorNo: UILabel!
    
}
