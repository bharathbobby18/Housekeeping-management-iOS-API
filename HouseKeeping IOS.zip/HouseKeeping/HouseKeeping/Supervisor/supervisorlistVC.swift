//
//  supervisorlistVC.swift
//  HouseKeeping
//
//  Created by SAIL on 14/10/23.
//

import UIKit

class supervisorlistVC: UIViewController {
    @IBOutlet weak var supervisor: UITableView!{
        didSet{
            supervisor.delegate = self
            supervisor.dataSource = self
        }
    }
    var employee: EmployeeModel!
    var apiUrl = String()
    var selectedCellIndex: IndexPath?

    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getSupervisorAPI()
    }
    @IBAction func submit(_ sender: Any) {
        if let  bioids : String = UserDefaultsManager.shared.getValue(forKey: "DeleteEmp"){
            self.DeleteEmployeeData(bioID: bioids) //

        }

    }
    func getSupervisorAPI() {
       
        if let DelEmp : String = UserDefaultsManager.shared.getValue(forKey: "DeleteEmployee"){
            if DelEmp == "Delete Supervisor" { //
                apiUrl = ServiceAPI.supervisorList
            }
            else if DelEmp == "Delete Worker" {
                apiUrl = ServiceAPI.workerList
            }
            else if DelEmp == "Delete Manager" {

                apiUrl = ServiceAPI.managerList
            }
        }
        
        
        APIHandler().getAPIValues(type: EmployeeModel.self, apiUrl: apiUrl, method: "GET") { result in
            switch result {
            case .success(let data):
                self.employee = data
                print(self.employee.data ?? "")
                print(self.employee.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.supervisor.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func DeleteEmployeeData(bioID : String){
        let formData : [String:String] = ["bio_id": bioID]
        APIHandler().postAPIValues(type: SucessModel.self, apiUrl: ServiceAPI.deleteEmployee, method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                print(data)
                DispatchQueue.main.async {
                    self.supervisor.reloadData()
                    self.getSupervisorAPI()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
extension supervisorlistVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return employee?.data?.count ?? 1
    }
    // Define a property to keep track of the selected cell's index

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = supervisor.dequeueReusableCell(withIdentifier: "UserTableViewCell", for: indexPath) as! UserTableViewCell
        
        if let employeeData = self.employee?.data, indexPath.row < employeeData.count {
            let bioName = employeeData[indexPath.row]
            cell.userNameLbl.text = "\(bioName.bioID ?? "") \n \(bioName.firstName ?? "")"
            
            // Check if the current cell is selected
            if indexPath == selectedCellIndex {
                cell.radioBtn.setImage(UIImage(named: "radio_On"), for: .normal)
            } else {
                cell.radioBtn.setImage(UIImage(named: "radio_Off"), for: .normal)
            }
            
            cell.radioBtn.addAction(for: .tap) {
                // Set the new selected index
                self.selectedCellIndex = indexPath
                
                // Reload the table to update the cell's appearance
                tableView.reloadData()
                
                if let bioID = bioName.bioID {
                    
                    UserDefaultsManager.shared.setValue(bioID, forKey: "DeleteEmp")
                    // Handle the tap action or perform other tasks here
                }
            }
        } else {
            // Handle the case where indexPath is out of range or employee.data is nil
        }
        
        return cell
    }

}

