//
//  SupervisorInfoCell.swift
//  HouseKeeping
//
//  Created by SAIL on 28/10/23.
//

import UIKit

class SupervisorInfoCell: UITableViewCell {
    @IBOutlet weak var radio : UIButton!
    @IBOutlet weak var name : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
