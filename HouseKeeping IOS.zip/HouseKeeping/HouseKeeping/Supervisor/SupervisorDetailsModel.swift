//
//  SupervisorDetailsModel.swift
//  HouseKeeping
//
//  Created by SAIL on 28/10/23.

import Foundation

// MARK: - Welcome
struct SupervisorDetailsModel: Codable {
    var data: [SupervisorDetailsDatum]?
}

// MARK: - Datum
struct SupervisorDetailsDatum: Codable {
    var assetID, assetName, assetQuantity, date: String?

    enum CodingKeys: String, CodingKey {
        case assetID = "asset_id"
        case assetName = "asset_name"
        case assetQuantity = "asset_quantity"
        case date
    }
}
