//
//  SupervisorJobVC.swift
//  HouseKeeping
//
//  Created by SAIL on 19/10/23.
//

import UIKit

class SupervisorJobVC: UIViewController {
    
    @IBOutlet weak var supervisorJobTable: UITableView! {
        didSet {
            supervisorJobTable.delegate = self
            supervisorJobTable.dataSource = self
        }
    }
    var supervisorData : SupervisorJobModel? {
        didSet {
            if let supervisorData = supervisorData {
                print(supervisorData)
            }
            else {print("No Data Available")}
        }
    }
    @IBOutlet weak var back: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        self.UpcomingJob()
    }
    
    func UpcomingJob(){
//        let bioID : String = UserDefaultsManager.shared.getValue(forKey: "bio_id") as! String
        APIHandler().getAPIValues(type: SupervisorJobModel.self, apiUrl: "\(ServiceAPI.supervisorJob)bio_id=\(ServiceAPI.bioId)", method: "GET") { Result in
            switch Result {
            case.success(let data):
                self.supervisorData = data
                print(data)
                DispatchQueue.main.async {
                    self.supervisorJobTable.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }  
    }
    
    
}


extension SupervisorJobVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return supervisorData?.jobs?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = supervisorJobTable.dequeueReusableCell(withIdentifier: "SupervisorJobCell") as! SupervisorJobCell
        
        if let superData = supervisorData?.jobs?[indexPath.row] {
            // Check if the job data is available before accessing its properties
            cell.jobId.text = superData.job_id
            cell.supervisorName.text = superData.supervisor
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "DoorAssignedVC") as! DoorAssignedVC
            if let superData = supervisorData?.jobs?[indexPath.row] {
                nextVC.selectedJobId = superData.job_id ?? ""
                nextVC.selectedFloor = superData.floor_no ?? ""
            }
            self.navigationController?.pushViewController(nextVC, animated: true)
    }
}


