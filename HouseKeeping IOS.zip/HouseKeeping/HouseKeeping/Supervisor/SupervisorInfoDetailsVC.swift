//
//  SupervisorInfoDetailsVC.swift
//  HouseKeeping
//
//  Created by SAIL on 28/10/23.
//

import UIKit

class SupervisorInfoDetailsVC: UIViewController {

    @IBOutlet weak var supervisorinfoDetailsList: UITableView!{
        didSet{
            supervisorinfoDetailsList.delegate = self
            supervisorinfoDetailsList.dataSource = self
        }
    }
    var supervisorData : SupervisorDetailsModel? {
        didSet {
            if let supervisorData = supervisorData {
                print(supervisorData)
            }
            else {
                print("No Data Available")
            }
        }
    }
    @IBOutlet weak var back: UIImageView!
    var bioID = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        self.GetSupervisorInfoDetailsAPI()
    }
    @IBAction func done(_ sender: Any) {
        let homeVC = UIStoryboard(name: "HomeStory", bundle: nil).instantiateViewController(withIdentifier: "TabbarVC") as! TabbarVC
        self.navigationController?.pushViewController(homeVC, animated: true)
    }
    
    
    
    func GetSupervisorInfoDetailsAPI() {
        APIHandler().getAPIValues(type: SupervisorDetailsModel.self, apiUrl: "\(ServiceAPI.supervisorListDetails)bio_id=\(bioID)", method: "GET") { Result in
            switch Result {
            case.success(let data):
                print(data)
                self.supervisorData = data
                DispatchQueue.main.async {
                    self.supervisorinfoDetailsList.reloadData()
                }
            case.failure(let error):
                print(error)
                
            }
        }
    }

}

extension SupervisorInfoDetailsVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return supervisorData?.data?.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = supervisorinfoDetailsList.dequeueReusableCell(withIdentifier: "SupervisorInfoDetailsCell") as! SupervisorInfoDetailsCell
        cell.assetId.text = supervisorData?.data?[indexPath.row].assetID ?? ""
        cell.assetName.text = supervisorData?.data?[indexPath.row].assetName ?? ""
        cell.data.text = supervisorData?.data?[indexPath.row].date ?? ""
        cell.qty.text = supervisorData?.data?[indexPath.row].assetQuantity ?? ""
        return cell
    }
}


class SupervisorInfoDetailsCell : UITableViewCell {

    @IBOutlet weak var assetId : UILabel!
    @IBOutlet weak var assetName : UILabel!
    @IBOutlet weak var data : UILabel!
    @IBOutlet weak var qty : UILabel!
}
