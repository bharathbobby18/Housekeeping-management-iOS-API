//
//  Constant.swift
//  WeatherApp
//
//  Created by Haris Madhavan on 06/09/23.
//

import Foundation
import UIKit

struct ServiceAPI {
    static var bioId = String()
    static var ipAddress = "http://192.168.118.40/house1/"
    static var login = ipAddress+"login.php?"
    static var assert = ipAddress+"assetreq.php"
    static var assetReqtd = ipAddress+"assetreq1.php"
    static var supervisorList = ipAddress+"supervisor.php"
    static var managerList = ipAddress+"managerlist.php"
    static var workerList = ipAddress+"workerlist.php"
    static var addEmpSuccess = ipAddress+"addemp.php?"
    static var deleteEmployee   = ipAddress+"delete.php?"
    static var addBill = ipAddress+"addbul.php?"
    static var managerAssignJob = ipAddress+"assignp.php?" // post Method prams - from, to, floor_no, supervisor
    static var jobStatus  = ipAddress+"jobstatus.php?"
    static var supervisorJob  = ipAddress+"sloginwel.php?"
    static var requestedAssets = ipAddress+"requestedasset.php?"
    static var assetListDetails = ipAddress+"assdetails.php?"
    static var supervisorListDetails = ipAddress+"assethis.php?"
    static var acptAssetDetails = ipAddress+"reqacceptbtn.php?"
    static var workerNames = ipAddress+"workername.php?"
}

