//
//  settingsViewController.swift
//  HouseKeeping
//
//  Created by SAIL on 01/11/23.
//

import UIKit

class settingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func logout(_ sender: Any) {
        
        let nextV = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UserLoginVC") as! UserLoginVC
        self.navigationController?.pushViewController(nextV, animated: true)
        
    }
    

    }
    


