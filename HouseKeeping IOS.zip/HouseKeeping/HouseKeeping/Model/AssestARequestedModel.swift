//
//  AssestARequestedModel.swift
//  HouseKeeping
//
//  Created by Karthik Babu on 17/11/23.
//

import Foundation

// MARK: - Welcome
struct AssestRequestedModel: Codable {
    var status: Bool?
    var message: String?
    var assetReqListDetails: [AssetReqListDetail]?
}

// MARK: - AssetReqListDetail
struct AssetReqListDetail: Codable {
    var assetID, requestQuantity: Int?

    enum CodingKeys: String, CodingKey {
        case assetID = "asset_id"
        case requestQuantity = "request_quantity"
    }
}
