//
//  AssetRequestModel.swift
//  HouseKeeping
//
//  Created by SAIL on 10/10/23.
//

import Foundation

// MARK: - Welcome
struct AssetsRequests: Codable {
    var assets: [Asset]?
}

// MARK: - Asset
struct Asset: Codable {
    var assetID, assetName, assetQuantity: String?

    enum CodingKeys: String, CodingKey {
        case assetID = "asset_id"
        case assetName = "asset_name"
        case assetQuantity = "asset_quantity"
    }
}
