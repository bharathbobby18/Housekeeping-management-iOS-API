//
//  WorkerModel.swift
//  HouseKeeping
//
//  Created by SAIL on 30/10/23.
//

import Foundation


// MARK: - Welcome
struct WorkerModel: Codable {
    var data: [WorkerData]?
}

// MARK: - Datum
struct WorkerData: Codable {
    var bioID, firstName: String?

    enum CodingKeys: String, CodingKey {
        case bioID = "bio_id"
        case firstName
    }
}
