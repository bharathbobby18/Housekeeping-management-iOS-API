//
//  SupervisorJobModel.swift
//  HouseKeeping
//
//  Created by SAIL on 30/10/23.
//

//import Foundation
//
//// MARK: - Welcome
//struct SupervisorJobModel: Codable {
//    var data: SupervisorJob?
//}
//
//// MARK: - DataClass
//struct SupervisorJob: Codable {
//    var status: Bool?
//    var jobs: [Job]?
//}
//
//// MARK: - Job
//struct Job: Codable {
//    var jobID, floorNo, fromDate, toDate: String?
//    var supervisor: String?
//
//    enum CodingKeys: String, CodingKey {
//        case jobID = "job_id"
//        case floorNo = "floor_no"
//        case fromDate = "from_date"
//        case toDate = "to_date"
//        case supervisor
//    }
//}

import Foundation

// MARK: - Welcome
struct SupervisorJobModel : Codable {
    var status: Bool?
    var jobs: [Job]?
}

// MARK: - Job
struct Job : Codable {
    var job_id, floor_no, from_date, to_date: String?
    var status : String?
    var supervisor: String?
}
