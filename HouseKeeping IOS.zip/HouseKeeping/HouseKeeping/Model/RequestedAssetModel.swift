//
//  RequestedAssetModel.swift
//  HouseKeeping
//
//  Created by SAIL on 28/10/23.
//
import Foundation

// MARK: - Welcome
struct RequestedAssetModel: Codable {
    var data: [RequestedData]?
}

// MARK: - Datum
struct RequestedData: Codable {
    var bioID, firstname: String?

    enum CodingKeys: String, CodingKey {
        case bioID = "bio_id"
        case firstname
    }
}
