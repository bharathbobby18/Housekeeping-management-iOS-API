//
//  File.swift
//  HouseKeeping
//
//  Created by SAIL on 28/10/23.
//
import Foundation

// MARK: - Welcome
struct AssetListDetailsModel: Codable {
    var status, message: String?
    var data: [AssetListData]?
}

// MARK: - Datum
struct AssetListData: Codable {
    var assetID, assetName, requestQuantity: String?

    enum CodingKeys: String, CodingKey {
        case assetID = "asset_id"
        case assetName = "asset_name"
        case requestQuantity = "request_quantity"
    }
}
