//
//  LoginVC.swift
//  HouseKeeping
//
//  Created by SAIL on 11/09/23.
//

import UIKit

class LoginVC: ViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Your code here
    }

}
